<?php
// var_dump($_GET);
if($_GET['username'] === 'admin'){
 echo "true";
} else {
  echo "false";
}

?>